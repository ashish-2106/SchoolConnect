// app/teacher/dashboard/page.tsx
"use client";

import React, { useEffect, useState } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useRouter } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, LogOut } from "lucide-react";

export default function TeacherDashboard() {
  const router = useRouter();
  const [data, setData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        router.push("/(auth)/login");
        return;
      }
      try {
        const url = `/api/teachers/dashboard?email=${encodeURIComponent(user.email ?? "")}`;
        const res = await fetch(url);
        if (!res.ok) {
          console.error("Dashboard API failed", res.status, await res.text().catch(() => ""));
          setData(null);
        } else {
          const json = await res.json();
          setData(json);
        }
      } catch (e) {
        console.error("Fetch dashboard error", e);
        setData(null);
      } finally {
        setLoading(false);
      }
    });

    return () => unsub();
  }, [router]);

  if (loading)
    return (
      <div className="flex items-center justify-center py-10 text-muted-foreground">
        <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Loading dashboard...
      </div>
    );

  if (!data)
    return <div className="p-8 text-center text-red-600">No data found for your account.</div>;

  return (
    <div className="max-w-6xl mx-auto py-10 px-4 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Welcome, Mr.{data.teacherName}</h1>
          <p className="text-sm text-muted-foreground">{data.teacherEmail}</p>
        </div>
        <Button variant="destructive" onClick={async () => { await signOut(auth); router.push("/"); }}>
          <LogOut className="w-4 h-4 mr-2" /> Logout
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card><CardContent><p>Classes</p><h3 className="text-2xl">{data.totalClasses}</h3></CardContent></Card>
        <Card><CardContent><p>Students</p><h3 className="text-2xl">{data.totalStudents}</h3></CardContent></Card>
        <Card><CardContent><p>Pending Attendance</p><h3 className="text-2xl">—</h3></CardContent></Card>
      </div>
    </div>
  );
}
