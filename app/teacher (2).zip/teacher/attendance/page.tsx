"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2 } from "lucide-react";

export default function AttendancePage() {
  const { id } = useParams(); // ✅ id from /teacher/classes/[id]/attendance
  const [students, setStudents] = useState<any[]>([]);
  const [attendance, setAttendance] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStudents() {
      try {
        if (!id) return;
        const res = await fetch(`/api/classes/${id}/students`);
        if (!res.ok) {
          console.error("Failed to load students", res.status);
          setStudents([]);
          return;
        }
        const data = await res.json();
        if (Array.isArray(data)) {
          setStudents(data);
        } else {
          console.error("Invalid data:", data);
          setStudents([]);
        }
      } catch (e) {
        console.error("Error fetching students:", e);
        setStudents([]);
      } finally {
        setLoading(false);
      }
    }
    loadStudents();
  }, [id]);

  const handleToggle = (studentId: string) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: !prev[studentId],
    }));
  };

  const handleSubmit = async () => {
    const absent = students.filter((s) => !attendance[s.id]);
    alert(`Absent: ${absent.map((s) => s.name).join(", ")}`);
  };

  if (loading)
    return (
      <div className="flex justify-center py-10 text-muted-foreground">
        <Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading students...
      </div>
    );

  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold mb-6">Mark Attendance</h1>
      <Card className="max-w-lg">
        <CardContent className="p-4 space-y-3">
          {students.length === 0 ? (
            <p className="text-muted-foreground text-center">
              No students found for this class.
            </p>
          ) : (
            students.map((student) => (
              <div key={student.id} className="flex items-center space-x-3">
                <Checkbox
                  checked={attendance[student.id] ?? false}
                  onCheckedChange={() => handleToggle(student.id)}
                />
                <span>{student.name}</span>
              </div>
            ))
          )}
          <Button onClick={handleSubmit} className="mt-4 w-full">
            Submit Attendance
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
