"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, ArrowLeft } from "lucide-react";

export default function AttendancePage() {
  const { id } = useParams();
  const router = useRouter();
  const [students, setStudents] = useState<any[]>([]);
  const [attendance, setAttendance] = useState<Record<string, boolean>>({});
  const [className, setClassName] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    async function loadStudents() {
      try {
        if (!id) return;
        const res = await fetch(`/api/classes/${id}/students`);
        if (!res.ok) {
          console.error("Failed to load students", res.status);
          setStudents([]);
          return;
        }

        const data = await res.json();
        // ✅ Expect: { students: [...], class: { name: "12" } }
        if (data.students) {
          setStudents(data.students);
          setClassName(data.class?.name || "");
          const initial = Object.fromEntries(
            data.students.map((s: any) => [s.id, true]) // all present by default
          );
          setAttendance(initial);
        } else {
          setStudents([]);
        }
      } catch (e) {
        console.error("Error fetching students:", e);
        setStudents([]);
      } finally {
        setLoading(false);
      }
    }
    loadStudents();
  }, [id]);

  const handleToggle = (studentId: string) => {
    setAttendance((prev) => ({
      ...prev,
      [studentId]: !prev[studentId],
    }));
  };

  const handleSubmit = async () => {
    const presentIds = Object.keys(attendance).filter((id) => attendance[id]);
    const absentIds = Object.keys(attendance).filter((id) => !attendance[id]);

    setSubmitting(true);
    try {
      const res = await fetch("/api/attendance/mark", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          classId: id,
          presentIds,
          absentIds,
          date: new Date().toISOString().split("T")[0],
        }),
      });

      if (!res.ok) {
        console.error("Failed to mark attendance");
        alert("Failed to mark attendance");
        return;
      }

      alert("✅ Attendance saved successfully!");
      router.back();
    } catch (e) {
      console.error("Error submitting attendance:", e);
      alert("Error saving attendance");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading)
    return (
      <div className="flex justify-center py-10 text-muted-foreground">
        <Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading students...
      </div>
    );

  return (
    <div className="p-8">
      {/* ✅ Back button */}
      <div className="mb-4">
        <Button
          variant="outline"
          className="flex items-center gap-2"
          onClick={() => router.back()}
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </Button>
      </div>

      <h1 className="text-2xl font-semibold mb-6">
        Mark Attendance for {className || id}
      </h1>

      <Card className="max-w-lg">
        <CardContent className="p-4 space-y-3">
          {students.length === 0 ? (
            <p className="text-muted-foreground text-center">
              No students found for this class.
            </p>
          ) : (
            students.map((student) => (
              <div key={student.id} className="flex items-center space-x-3">
                <Checkbox
                  checked={attendance[student.id] ?? false}
                  onCheckedChange={() => handleToggle(student.id)}
                />
                <span>
                  {student.name}{" "}
                  {!attendance[student.id] && (
                    <span className="text-red-500 text-sm">(Absent)</span>
                  )}
                </span>
              </div>
            ))
          )}

          <Button
            onClick={handleSubmit}
            disabled={submitting}
            className="mt-4 w-full"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...
              </>
            ) : (
              "Submit Attendance"
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
