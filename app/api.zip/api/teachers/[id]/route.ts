// app/api/teachers/[id]/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/db";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const id = params.id;
  const teacher = await prisma.teacher.findUnique({
    where: { id },
    include: { user: true, classes: true },
  });
  if (!teacher) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({
    id: teacher.id,
    name: teacher.user?.name,
    email: teacher.user?.email,
    classes: teacher.classes,
  });
}

export async function PUT(req: Request, { params }: { params: { id: string } }) {
  const id = params.id;
  const body = await req.json();
  const { name, email } = body;

  const teacher = await prisma.teacher.findUnique({ where: { id }, include: { user: true } });
  if (!teacher) return NextResponse.json({ error: "Not found" }, { status: 404 });

  // update user record
  const updatedUser = await prisma.user.update({
    where: { id: teacher.userId },
    data: { name: name ?? teacher.user?.name, email: email ?? teacher.user?.email },
  });

  return NextResponse.json({ ok: true, user: updatedUser });
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const id = params.id;
  const teacher = await prisma.teacher.findUnique({ where: { id } });
  if (!teacher) return NextResponse.json({ error: "Not found" }, { status: 404 });

  // optionally, delete user and cascade
  await prisma.teacher.delete({ where: { id } });
  // NOTE: keep the user record if you prefer; for now we leave the user
  return NextResponse.json({ ok: true });
}
