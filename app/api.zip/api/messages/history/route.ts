// app/api/messages/history/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/db";

export async function GET() {
  const msgs = await prisma.message.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
  // map to friendly shape
  const payload = msgs.map((m) => ({
    id: m.id,
    senderId: m.senderId,
    message: m.message,
    method: m.type,
    targets: m.targets,
    createdAt: m.createdAt,
  }));
  return NextResponse.json(payload);
}
