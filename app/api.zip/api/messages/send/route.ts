// app/api/messages/send/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/db";
import { sendSMS, sendEmail, sendWhatsApp } from "@/lib/senders";

/**
 * Expected payload:
 * {
 *   method: 'SMS' | 'EMAIL' | 'WHATSAPP',
 *   targets: ['all'] | ['classId'] | ['studentId'] (array),
 *   message: string
 * }
 */

export async function POST(req: Request) {
  try {
    const { method, targets, message } = await req.json();
    if (!method || !targets || !message) {
      return NextResponse.json({ error: "method, targets and message required" }, { status: 400 });
    }

    // resolve recipients
    let recipients: { id: string; name?: string; contact: string }[] = [];

    if (Array.isArray(targets) && targets.includes("all")) {
      // fetch all students
      const students = await prisma.student.findMany();
      recipients = students.map((s) => ({ id: s.id, name: s.name, contact: s.parentContact }));
    } else {
      // targets might be student ids or class ids; we'll try both
      for (const t of targets) {
        // student?
        const student = await prisma.student.findUnique({ where: { id: t } });
        if (student) {
          recipients.push({ id: student.id, name: student.name, contact: student.parentContact });
          continue;
        }

        // class?
        const klass = await prisma.class.findUnique({ where: { id: t }, include: { students: true } });
        if (klass) {
          for (const s of klass.students) recipients.push({ id: s.id, name: s.name, contact: s.parentContact });
        }
      }
    }

    // dedupe by contact
    const dedup = new Map<string, { id: string; name?: string; contact: string }>();
    for (const r of recipients) dedup.set(r.contact, r);
    recipients = Array.from(dedup.values());

    const results: any[] = [];

    for (const r of recipients) {
      try {
        if (method === "SMS") {
          const res = await sendSMS(r.contact, message);
          results.push({ to: r.contact, ok: res.ok });
        } else if (method === "EMAIL") {
          const res = await sendEmail(r.contact, "School Announcement", message);
          results.push({ to: r.contact, ok: res.ok });
        } else if (method === "WHATSAPP") {
          const res = await sendWhatsApp(r.contact, message);
          results.push({ to: r.contact, ok: res.ok });
        } else {
          results.push({ to: r.contact, ok: false, error: "Unknown method" });
        }
      } catch (err) {
        results.push({ to: r.contact, ok: false, error: (err as any).message });
      }
    }

    // log message in DB
    await prisma.message.create({
      data: {
        senderId: "system", // could be session user id when auth integrated here
        message,
        type: method,
        targets: targets,
      },
    });

    return NextResponse.json({ ok: true, sent: results.length, results });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "failed to send" }, { status: 500 });
  }
}
