// app/api/classes/[id]/students/route.ts
import { NextResponse } from "next/server";
import prisma from "@/lib/db"; // ensure this path matches your project

export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const id = params?.id;
    if (!id) {
      return NextResponse.json({ ok: false, error: "Missing class id" }, { status: 400 });
    }

    // load class with students (adjust field names to your schema)
    const classData = await prisma.class.findUnique({
      where: { id },
      include: { students: true },
    });

    if (!classData) {
      return NextResponse.json({ ok: false, error: "Class not found" }, { status: 404 });
    }

    // normalize student objects for the client
    const students = classData.students.map((s: any) => ({
      id: s.id,
      name: s.name,
      rollNo: s.rollNo ?? s.roll ?? null,
      parentName: s.parentName ?? null,
      parentEmail: s.parentEmail ?? null,
      parentContact: s.parentContact ?? null,
    }));

    // return a stable shape: { ok: true, students: [] }
    return NextResponse.json({ ok: true, students }, { status: 200 });
  } catch (err: any) {
    console.error("Error in GET /api/classes/[id]/students:", err);
    return NextResponse.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
