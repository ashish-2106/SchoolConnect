import { NextResponse } from "next/server";
import prisma from "@/lib/db";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const email = searchParams.get("email");

    if (!email)
      return NextResponse.json({ error: "Email required" }, { status: 400 });

    // ✅ Check admin email from .env
    if (email === process.env.NEXT_PUBLIC_ADMIN_EMAIL) {
      return NextResponse.json({ role: "ADMIN" });
    }

    // ✅ Otherwise, check in database
    const user = await prisma.user.findUnique({
      where: { email },
      select: { role: true },
    });

    if (!user)
      return NextResponse.json({ role: "UNKNOWN" }, { status: 404 });

    return NextResponse.json({ role: user.role });
  } catch (err) {
    console.error("Role fetch failed:", err);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
